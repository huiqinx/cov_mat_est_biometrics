rm(list=ls())
lib.path = '~/rlib/'
.libPaths(lib.path)
library(pracma)
library(matrixStats)
library(doParallel)
library(foreach)
source('~/cov_new/methods.R')

T.max = 50
n = 100; p = 1000
methods = list(msg_sgrid_km,posdef.correction, adap.thrsd, 
               linear,QIS,NERCOME,corShrink,SCM,
               oracle_nonlin,oracle_gmleb)
n.methods = length(methods) # positive correction and sample cov matrix
mat.types = c('sparse')

n.cluster = detectCores()
print(paste(n.cluster,'clusters are detected.'))
cl = makeCluster(2)
registerDoParallel(cl)
clusterEvalQ(cl, .libPaths('~/rlib/'))
for (k in 1:length(mat.types))
{
  print(paste('simulation for',mat.types[k]))
  # construct error matrix
  f.median = rep(0,n.methods)
  names(f.median) = c('msg_sgrid_km','msg_km_cor','adap.thrsd', 'linear',
                         'QIS','NERCOME','corShrink','SCM',
                         'oracle_nonlin','oracle_gmleb')
  f.range = f.median
  t.mean = f.median
  start_time_all <- Sys.time()
  set.seed(123)
  sigma.x = build_matrix(p,choice = mat.types[k])

  res <- foreach(b = 1:T.max, .combine = "rbind", .packages = c('MASS','ashr','pracma','matrixStats')) %dopar% {
    .GlobalEnv$sigma.x <- sigma.x 
    .GlobalEnv$npmle2 <- npmle2
    .GlobalEnv$pos.cor.cor <- pos.cor.cor
    X = mvrnorm(n,mu=rep(0,p),Sigma = sigma.x)
    f_errs = rep(0,n.methods)
    ts = rep(0,n.methods)
    for (im in 1:n.methods)
    {
      g = methods[[im]]
      start_time <- Sys.time()
      if (im == 1) # msg_sgrid_km
      {
        mat.hat = g(X,fun=npmle2,K=100,centered=TRUE)
      }
      else if(im == 2) # corrected msg_sgrid_km
      {
        mat.hat = g(mat.hat,d=20,lp=p)
      }
      else if(im == 10) # oracle gmleb
      {
        mat.hat = g(X,K=100,cov=sigma.x,centered=TRUE)
      }
      else if(im == 9) # oracle nonlinear
      {
        mat.hat = g(X,cov=sigma.x,centered=TRUE)
      }
      else if(im == 7) # corShrink
      {
        S = var(X)
        sd.hat = sqrt(diag(S))
        cormat.hat = g(X)
        mat.hat = diag(sd.hat) %*% cormat.hat %*% diag(sd.hat)
      }
      else # other methods
      {
        mat.hat = g(X,centered=TRUE)
      }
      end_time <- Sys.time()
      
      f_errs[im] = norm(sigma.x-mat.hat, type = "f")
      ts[im] = end_time - start_time
      
    }
    c(f_errs, ts)
  }
  
  f.median = colMedians(res[,1:n.methods]) 
  f.range = colQuantiles(res[,1:n.methods], probs = 0.75) -
    colQuantiles(res[,1:n.methods], probs = 0.25)
  t.mean = colMeans(res[,(n.methods+1):(2*n.methods)]) 
    
  end_time_all <- Sys.time()
  t_all = end_time_all - start_time_all
  print(f.median)
  print(f.range)
  print(t.mean) 
  print(t_all)
}
stopCluster(cl)