.libPaths('~/rlib/')
library(MASS)
library(Matrix)

build_matrix = function(lp,choice='dense')
{
  lb=1; ub=1.5
  if(choice=='dense')
  {
    # mat.x is dense matrix without constant correlation=0.9
    cor.mat = matrix(0.7, lp,lp)
    diag(cor.mat) = 1
    # standard deviations are generated from U[1,1.5]
    sd = c(rep(lb,lp/2),rep(ub,lp/2))
    sigma.x = diag(sd) %*% cor.mat %*% diag(sd)
  }
  else if(choice=='dense2')
  {
    # mat.x is dense matrix without constant correlation=0.9
    cor.mat = matrix(0.9, lp,lp)
    diag(cor.mat) = 1
    # standard deviations are generated from U[1,1.5]
    sd = c(rep(lb,lp/2),rep(ub,lp/2))
    sigma.x = diag(sd) %*% cor.mat %*% diag(sd)
  }
  
  else if(choice == 'block')
  {
    # mat.x is diagonal matrix of which variances and correlations are correlated
    sigma.x = matrix(0.4 * 2 * 1, lp, lp)
    sigma.x[1:(lp / 2), 1:(lp / 2)] = matrix(3.2, lp / 2, lp / 2)
    sigma.x[(lp / 2 + 1):lp, (lp / 2 + 1):lp] = matrix(0.2, lp / 2, lp / 2)
    diag(sigma.x) = c(rep(4, lp / 2), rep(1, lp / 2))
  }
  
  else if(choice=='sparse')
  {
    # mat.x is sparse matrix with ordering
    bx = matrix(rep(0, lp^2/4), lp/2)
    for(s in 1:9)
    {
      
      bx[(s+1):(lp/2),1:(lp/2-s)] = bx[(s+1):(lp/2),1:(lp/2-s)]+
        diag(rep(1-0.1*s,lp/2-s))
      
    }
    bx = bx + t(bx)
    diag(bx) = 1
    cor.mat=bdiag(diag(lp/2), bx)
    sd = c(rep(lb,lp/2),rep(ub,lp/2))
    sigma.x = diag(sd) %*% cor.mat %*% diag(sd)
    sigma.x = as.matrix(sigma.x)
  }
  else if(choice=='orth')
  {
    U <- randortho(lp)
    eige.vs = runif(lp,1,4)
    sigma.x = U %*% diag(eige.vs) %*% t(U) 
  }
  else if(choice=='spiked')
  {
    U <- randortho(lp)
    eige.vs = rep(1,lp) + c(3,2,1,rep(0,lp-3))
    sigma.x = U %*% diag(eige.vs) %*% t(U) 
  }
  return(sigma.x)
}

posdef.correction = function(Sigma, d, lp)
{
  alphas = seq(0,10,length.out = d)
  eig = eigen(Sigma)
  sigma.eig = eig$values
  U = eig$vectors
  lam.min = min(sigma.eig[sigma.eig>0])
  c = 10^(-alphas) * lam.min
  loss = rep(0,d)
  for(i in 1:d)
  {
    lam = pmax(sigma.eig, c[i])
    Sigma1 = U %*% diag(lam) %*% t(U)
    loss[i] = norm(Sigma1-Sigma,'f')/sqrt(lp)+alphas[i]
    
  }
  i.m = which.min(loss)
  lam = pmax(sigma.eig, c[i.m])
  Sigma1 = U %*% diag(lam) %*% t(U)
  return(Sigma1)
}
## npmle
## D: p x d matrix of conditional density values
## maxit: maximum number of EM iterations
## tol: error tolerance
npmle = function (D, maxit = 200, tol = 1e-04, verbose = FALSE)  {
  lp = nrow(D)
  d = ncol(D)
  g = rep(1/d, d)
  oldll = 0
  for (it in 1:maxit) {
    tmp = D %*% g
    newll = sum(log(tmp))
    err = abs(newll - oldll)/abs(oldll)
    if (err <= tol) {
      break
    }
    else {
      oldll = newll
      g = crossprod(D, 1/tmp) * g / lp
      if (verbose)
        cat("Iter", it, ", error", err, "\n")
    }
  }
  if (it == maxit) {
    warning("Maximum number of iterations reached.")
  }
  return(g)
}

npmle2 = function (D, maxit = 200, tol = 1e-04, verbose = FALSE)  {
  lp = nrow(D)
  d = ncol(D)
  g = rep(1/d, d)
  D.l = D[,1:(d/2)]
  D.u = D[,(d/2+1):d]
  D.half = (D.l + D.u) / 2
  D.avg = cbind(D.half, D.half)
  oldll = 0
  for (it in 1:maxit) {
    tmp = D %*% g
    newll = sum(log(tmp))
    err = abs(newll - oldll)/abs(oldll)
    if (err <= tol) {
      break
    }
    else {
      oldll = newll
      g = crossprod(D.avg, 1/tmp) * g/lp
      if (verbose)
        cat("Iter", it, ", error", err, "\n")
    }
  }
  if (it == maxit) {
    warning("Maximum number of iterations reached.")
  }
  return(g)
}

# only estimate prior distribution of off-diagonal parameters (no cluster)
msg_sgrid = function(X, fun, centered=FALSE, maxit = 200, tol = 1e-4, verbose = FALSE) {
  lp = ncol(X); ln=nrow(X)
  if (centered) {
    ln = ln-1
    X = scale(X, scale = FALSE)
  }
  S = t(X) %*% X 
  ## make grid
  sds = sqrt(diag(S / ln))
  row_sdmat = replicate(lp,sds)
  col_sdmat = t(row_sdmat)
  cor_mat = S / ln / row_sdmat / col_sdmat
  grid = matrix(nrow=lp*(lp-1)/2,ncol=3)
  grid[,1] = row_sdmat[lower.tri(row_sdmat, diag=F)]
  grid[,2] = col_sdmat[lower.tri(col_sdmat, diag=F)]
  grid[,3] = cor_mat[lower.tri(cor_mat, diag=F)]
  
  grid.l = grid
  grid.u = matrix(NA, nrow=lp*(lp-1)/2, ncol=3)
  grid.u[,1] = grid.l[,2]
  grid.u[,2] = grid.l[,1]
  grid.u[,3] = grid.l[,3]
  grid = rbind(grid.l, grid.u)
  
  cmbn = combn(lp, 2)
  cmbn = cmbn[c(2,1),]
  W.all = matrix(NA,nrow=ncol(cmbn),ncol = 4)
  W.all[,1] = S[cbind(cmbn[1,],cmbn[1,])]
  W.all[,2] = S[cbind(cmbn[1,],cmbn[2,])]
  W.all[,3] = W.all[,2]
  W.all[,4] = S[cbind(cmbn[2,],cmbn[2,])]
  det.W = W.all[,1] * W.all[,4] - W.all[,2]^2
  
  log.det.w = log(det.W)
  log.I1 = (ln-3)/2*log.det.w
  log.I4 = ln*log(2)+log(pi)/2+log(gamma(ln/2)) + log(gamma((ln-1)/2))
  
  D = apply(grid, 1, function(x) {
    ## off-diagonal
    sigma = matrix(c(x[1]^2, prod(x), prod(x), x[2]^2),nrow = 2)
    inv.sigma = solve(sigma)
    
    log.I2 = -(W.all %*% as.vector(inv.sigma)) / 2
    log.I3 = ln / 2 * log(det(sigma))
    tmp = log.I1 + log.I2 - log.I3 - log.I4
    off = exp(tmp)
    ## on-diagonal is scaled chi-square
    on = dchisq(diag(S)/x[1]^2, ln) * ln / x[1]^2
    return(c(off, on))
  })
  g = fun(D, maxit, tol, verbose)
  ind = lp * (lp-1) / 2 
  
  ## estimated covariance matrix
  denom = D %*% g
  tmp_nd = D[1:ind,] %*% (g * apply(grid, 1, prod)) / denom[1:ind]
  tmp_d = D[(ind+1):(ind+lp),] %*% (g * grid[,1]^2) / denom[(ind+1):(ind+lp)]
  est_cov = matrix(0, lp, lp)
  est_cov[cbind(cmbn[1,],cmbn[2,])] = as.vector(tmp_nd)
  est_cov[cbind(cmbn[2,],cmbn[1,])] = as.vector(tmp_nd)
  diag(est_cov) = as.vector(tmp_d)
  
  return(est_cov)
}


# only estimate prior distribution of off-diagonal parameters
msg_sgrid_km = function(X, fun, K=10, n_start=20, centered=FALSE, maxit = 200, tol = 1e-4, verbose = FALSE) {
  lp = ncol(X); ln=nrow(X)
  if (centered) {
    ln = ln-1
    X = scale(X, scale = FALSE)
  }
  S = t(X) %*% X 
  ## make grid
  sds = sqrt(diag(S / ln))
  row_sdmat = replicate(lp,sds)
  col_sdmat = t(row_sdmat)
  cor_mat = S / ln / row_sdmat / col_sdmat
  grid = matrix(nrow=lp*(lp-1)/2,ncol=3)
  grid[,1] = row_sdmat[lower.tri(row_sdmat, diag=F)]
  grid[,2] = col_sdmat[lower.tri(col_sdmat, diag=F)]
  grid[,3] = cor_mat[lower.tri(cor_mat, diag=F)]
  nd_grid = grid
  n_dis = nrow(unique(nd_grid))
  K1 = min(n_dis,K)
  
  # grid clusters for non-diagonal entries
  if (n_dis < K)
  {
    grid.l = as.matrix(unique(nd_grid))
  }
  else
  {
    cnd_grid = scale(nd_grid)
    ct_nd_grid = attr(cnd_grid, 'scaled:center')
    sc_nd_grid = attr(cnd_grid, 'scaled:scale')
    # set.seed(233)
    cl_nd = kmeans(cnd_grid, centers=K, nstart = n_start,iter.max = 100)
    cnd_centers = cl_nd$centers
    nd_centers = apply(cnd_centers, 1,function(x) {x * sc_nd_grid + ct_nd_grid})
    grid.l = t(nd_centers)
  }
  
  grid.u = matrix(NA, nrow=K1, ncol=3)
  grid.u[,1] = grid.l[,2]
  grid.u[,2] = grid.l[,1]
  grid.u[,3] = grid.l[,3]
  grid = rbind(grid.l, grid.u)
  
  cmbn = combn(lp, 2)
  cmbn = cmbn[c(2,1),]
  W.all = matrix(NA,nrow=ncol(cmbn),ncol = 4)
  W.all[,1] = S[cbind(cmbn[1,],cmbn[1,])]
  W.all[,2] = S[cbind(cmbn[1,],cmbn[2,])]
  W.all[,3] = W.all[,2]
  W.all[,4] = S[cbind(cmbn[2,],cmbn[2,])]
  det.W = W.all[,1] * W.all[,4] - W.all[,2]^2
  
  log.det.w = log(det.W)
  log.I1 = (ln-3)/2*log.det.w
  log.I4 = ln*log(2)+log(pi)/2+log(gamma(ln/2)) + log(gamma((ln-1)/2))
  
  D = apply(grid, 1, function(x) {
    ## off-diagonal
    sigma = matrix(c(x[1]^2, prod(x), prod(x), x[2]^2),nrow = 2)
    inv.sigma = solve(sigma)
    
    log.I2 = -(W.all %*% as.vector(inv.sigma)) / 2
    log.I3 = ln / 2 * log(det(sigma))
    tmp = log.I1 + log.I2 - log.I3 - log.I4
    off = exp(tmp)
    ## on-diagonal is scaled chi-square
    on = dchisq(diag(S)/x[1]^2, ln) * ln / x[1]^2
    return(c(off, on))
  })
  g = fun(D, maxit, tol, verbose)
  ind = lp * (lp-1) / 2 
  
  ## estimated covariance matrix
  denom = D %*% g
  tmp_nd = D[1:ind,] %*% (g * apply(grid, 1, prod)) / denom[1:ind]
  tmp_d = D[(ind+1):(ind+lp),] %*% (g * grid[,1]^2) / denom[(ind+1):(ind+lp)]
  est_cov = matrix(0, lp, lp)
  est_cov[cbind(cmbn[1,],cmbn[2,])] = as.vector(tmp_nd)
  est_cov[cbind(cmbn[2,],cmbn[1,])] = as.vector(tmp_nd)
  diag(est_cov) = as.vector(tmp_d)
  
  return(est_cov)
}

SCM = function(X,centered = FALSE)
{
  n1 = nrow(X)
  if(centered) {
    S = cov(X)
  } else {
    S = t(X) %*% X / n1
  }
  return(S)
}

# nonlinear shrinkage method (Ledoit&Wolf,2019)
nonlinShrink = function(X,centered = FALSE)
{
  n1=nrow(X); p1=ncol(X)
  if(centered) 
    {S = cov(X)}
  else
    {S = t(X) %*% X / n1}
  U = eigen(S)$vectors
  lambda = eigen(S)$values
  ordind = order(lambda, decreasing = F)
  lambda = lambda[ordind]; U = U[,ordind]
  
  # compute analytical nonlinear shrinkage kernel formula
  lambda = lambda[max(1,p1-n1+1):p1]
  L = replicate(min(p1,n1), lambda)
  h = n1^(-1/3)
  H = h * t(L)
  x = (L - t(L)) / H
  ftilde = (3/4/sqrt(5)) * rowMeans(pmax(1-x^2/5, 0) / H)
  Hftemp = (-3/10/pi) * x + (3/4/sqrt(5)/pi) * (1-x^2/5) *
    log( abs((sqrt(5)-x) / (sqrt(5)+x)) )
  #print(length( which( abs(sqrt(5)-x) <0.001 ) ))
  if(length( which( abs(x) == sqrt(5) ) ))
  {
    Hftemp[abs(x) == sqrt(5)] = (-3/10/pi) * x[abs(x) == sqrt(5)]}
  #print(sum(is.na(Hftemp)))
  
  Hftilde = rowMeans(Hftemp / H)
  if(p1<=n1)
  {
    dtilde = lambda / ((pi*(p1/n1)*lambda*ftilde)^2 +
                         (1-p1/n1-pi*(p1/n1)*lambda*Hftilde)^2)
  }
  else
  {
    Hftilde0 = (1/pi) * (3/10/h^2 + 3/4/sqrt(5)/h*(1-1/5/h^2) * 
                           log((1+sqrt(5)*h) / (1-sqrt(5)*h))) * mean(1/lambda)
    dtilde0 = 1 / (pi*(p1-n1)/n1*Hftilde0)
    dtilde1 = lambda / (pi^2 * lambda^2 * (ftilde^2 + Hftilde^2))
    dtilde = c(dtilde0 * rep(1,p1-n1), dtilde1)
  }
  
  mat = U %*% diag(dtilde) %*% t(U)
  return(mat)
}

QIS = function(X,centered = FALSE)
{
  n1=nrow(X); p1=ncol(X)
  c = p1/n1
  if(centered) {
    S = cov(X)
  } else {
    S = t(X) %*% X / n1
  }
  # optimal bandwidth
  h = min(c,1/c)^0.7 * p1^(-0.35)
  
  U = eigen(S)$vectors
  lambda = eigen(S)$values
  ordind = order(lambda, decreasing = F)
  lambda = lambda[ordind]; U = U[,ordind]
  
  # compute analytical nonlinear shrinkage kernel formula
  # lambda = lambda[max(1,p1-n1+1):p1]
  # L = replicate(min(p1,n1), lambda)
  lam.inv = 1/lambda[max(1,p1-n1+1):p1]
  
  theta.hat = function(x)
  {
    v = sapply(lam.inv, function(lam.j) 
      lam.j * (lam.j-x) / ((lam.j-x)^2+h^2*lam.j^2))
    return(mean(v))
  }
  Asquare.hat = function(x)
  {
    v2 = sapply(lam.inv, function(lam.j) 
      h * lam.j^2 / ((lam.j-x)^2+h^2*lam.j^2))
    return(theta.hat(x)^2+mean(v2)^2)
  }
  
  # if not singular
  if(c <= 1)
  {
    ieig.est = sapply(lam.inv, function(x)
      (1-c)^2*x + 2*c*(1-c)*x * theta.hat(x) + c^2*x*Asquare.hat(x))
  }
  else
  {
    ieig1 = (c-1) * mean(lam.inv) 
    ieig2 = lam.inv * sapply(lam.inv, function(x) Asquare.hat(x))
    ieig.est = c(rep(ieig1,p1-n1), ieig2)
  }
  eig.est = 1/ieig.est
  eig.est = eig.est * sum(lambda) / sum(eig.est)
  mat = U %*% diag(eig.est) %*% t(U)
  return(mat)
}

# linear shrinkage method (Ledoit&Wolf,2004)
linear = function(X,centered = FALSE) # X, Y--n x p matrix
{
  n1=nrow(X); p1=ncol(X)
  if(centered) {
    n1 = n1-1
    X = scale(X, scale = F)
  }
  S = t(X) %*% X / n1
  theta.mx = matrix(nrow=n1,ncol=p1^2)
  
  for(k in 1:n1)
  {
    theta.mx[k,] = as.vector(X[k,] %*% t(X[k,]))-as.vector(S)
  }
  M = sum(as.vector(theta.mx)^2) / (n1^2)
  mu = sum(diag(S))/p1
  d = norm(S-mu*diag(p1),'f')^2
  beta = M/d
  
  mat = (1-beta) * S + mu * beta * diag(p1)
  return(mat)
}

# Adaptive thresholding
adap.thrsd = function(X,centered = FALSE) 
{
  n1=nrow(X); p1=ncol(X)
  if(centered) {
    # n1 = n1-1
    X = scale(X, scale = F)
  }
  S = t(X) %*% X / n1
  theta.mx = matrix(nrow=n1,ncol=p1^2)
  
  for(k in 1:n1)
  {
    theta.mx[k,] = as.vector(X[k,]%*%t(X[k,]))-as.vector(S)
  }
  theta.x = colMeans(theta.mx^2)
  thresholds = 2 * sqrt(theta.x * log(p1) / n1)
  S = as.vector(S)
  inds= which(abs(S) <= thresholds)
  
  S[inds] = 0
  mat = matrix(S,p1)
  return(mat)
}

NERCOME = function(X, centered = FALSE, M=50)
{
  p1 = ncol(X); N = nrow(X)
  if(centered) {
    X = scale(X, scale = F)
  }
  ms = floor(c(2*sqrt(N),0.2*N,0.4*N,0.6*N,0.8*N,N-2.5*sqrt(N), N-1.5*sqrt(N)))
  n.m = length(ms)
  gm = vector('numeric',n.m)
  for(i.m in 1:n.m)
  {
    mat0 = matrix(0,nrow=p1,ncol=p1)
    for (i.t in 1:M)
    {
      m = ms[i.m]
      ind1 = sample(1:N,m,replace = F)
      X1 = X[ind1,]
      if(centered)
      {
        S1 = t(X1) %*% X1 / (m - 1)
      }
      else{
        S1 = t(X1) %*% X1 / m
      }
      
      X2 = X[-ind1,]
      if(centered)
      {
        S2 = t(X2) %*% X2 / (N - m - 1)
      }
      else{
        S2 = t(X2) %*% X2 / (N - m)
      }
      P1 = eigen(S1)$vectors
      D = diag(t(P1) %*% S2 %*% P1)
      sigma.m = P1 %*% diag(D) %*% t(P1)
      mat0 = mat0 + (sigma.m - S2)
    }
    mat0 = mat0 / M
    gm[i.m] = norm(mat0,'F')
  }
  n1 = ms[which.min(gm)]
  mat0 = matrix(0,nrow=p1,ncol=p1)
  # M = 2 * M
  for (i.t in 1:M)
  {
    ind1 = sample(1:N,n1,replace = F)
    X1 = X[ind1,]
    if(centered)
    {
      S1 = t(X1) %*% X1 / (n1 - 1)
    }
    else{
      S1 = t(X1) %*% X1 / n1
    }
    X2 = X[-ind1,]
    if(centered)
    {
      S2 = t(X2) %*% X2 / (N - n1 - 1)
    }
    else{
      S2 = t(X2) %*% X2 / (N - n1)
    }
    P1 = eigen(S1)$vectors
    D = diag(t(P1) %*% S2 %*% P1)
    sigma.m = P1 %*% diag(D) %*% t(P1)
    mat0 = mat0 + sigma.m 
  }
  mat = mat0 / M
  
  return(mat)
}

corShrink = function(X)
{
  ln = nrow(X); lp = ncol(X)
  cor.mat = cor(X)
  cor.vec = cor.mat[lower.tri(cor.mat)]
  betahat = sapply(cor.vec, function(x) log((1+x)/(1-x))/2)
  s = sqrt(1/(ln-1) + 2/(ln-1)^2)
  sebetahat = s
  ash = ash.workhorse(
    betahat,
    sebetahat,
    method = 'shrink',
    mixcompdist = 'uniform',
    mode = 'estimate'
  )
  z.post = ash$result$PosteriorMean
  cor.post = sapply(z.post, function(z) (exp(2*z)-1)/(exp(2*z)+1))
  
  est_cor = matrix(0, lp, lp)
  est_cor[lower.tri(est_cor)] = cor.post
  est_cor[upper.tri(est_cor)] = t(est_cor)[upper.tri(est_cor)]
  diag(est_cor) = 1
  est_cor = pos.cor.cor(est_cor)
  return(est_cor)
}

pos.cor.cor = function(cor.mat,tol=1e-06,maxit = 200)
{ 
  X = cor.mat; Y = cor.mat
  lp = nrow(X)
  iter = 0
  rel_diffX = Inf; rel_diffY = Inf; rel_diffXY = Inf;
  ds = matrix(0,lp,lp)
  while(max(c(rel_diffX, rel_diffY, rel_diffXY))>tol)
  {
    Xold = X
    R = Y - ds
    eig = eigen(R)
    V =eig$vectors
    D = eig$values
    A = V%*% diag(pmax(D,0)) %*% t(V)
    X = (t(A)+A)/2
    ds = X - R
    Yold = Y
    Y = X
    diag(Y) = 1
    rel_diffX = norm(X-Xold,'f')/norm(X,'f')
    rel_diffY = norm(Y-Yold,'f')/norm(Y,'f')
    rel_diffXY = norm(Y-X,'f')/norm(Y,'f')
    iter = iter+1
    if (iter == maxit)
    {
      warning("Maximum number of iterations reached.")
    }
    
  }
  return(X)
}


oracle_nonlin = function(X,cov=sigma.x, centered = FALSE)
{
  n1 = nrow(X)
  if (centered) {
    n1 = n1-1
    X = scale(X, scale = FALSE)
  }
  S = t(X) %*% X / n1
  U.sample=eigen(S)$vectors
  v.sample=eigen(S)$values
  
  dg = diag(t(U.sample) %*% sigma.x %*% U.sample)
  mat = U.sample %*% diag(dg) %*% t(U.sample)
  return(mat)
}

oracle_gmleb = function(X,cov=sigma.x,K=10, n_start=20, centered=FALSE, maxit = 200, tol = 1e-4, verbose = FALSE)
{
  ln = nrow(X); lp = ncol(X)
  if (centered) {
    ln = ln-1
    X = scale(X, scale = FALSE)
  }
  S = t(X) %*% X
  
  # derive true standard deviations and correlation matrix 
  sd = sqrt(diag(sigma.x))
  cor.mat = diag(1/sd) %*% sigma.x %*% diag(1/sd)
  ## make grid
  sd.rowmat = replicate(lp,sd)
  sd.colmat = t(sd.rowmat)
  sd.row = sd.rowmat[lower.tri(sd.rowmat, diag = FALSE)]
  sd.col = sd.colmat[lower.tri(sd.colmat, diag = FALSE)]
  grid_rho = cor.mat[lower.tri(cor.mat, diag = FALSE)]
  nd_grid = cbind(sd.row, sd.col, grid_rho)
  n_dis = nrow(unique(nd_grid))
  K1 = min(n_dis,K)
  
  # grid clusters for non-diagonal entries
  if (n_dis < K)
  {
    grid.l = as.matrix(unique(nd_grid))
  }
  else
  {
    cnd_grid = scale(nd_grid)
    ct_nd_grid = attr(cnd_grid, 'scaled:center')
    sc_nd_grid = attr(cnd_grid, 'scaled:scale')
    # set.seed(233)
    cl_nd = kmeans(cnd_grid, centers=K, nstart = n_start,iter.max = 100)
    cnd_centers = cl_nd$centers
    nd_centers = apply(cnd_centers, 1,function(x) {x * sc_nd_grid + ct_nd_grid})
    grid.l = t(nd_centers)
  }
  
  grid.u = matrix(NA, nrow=K1, ncol=3)
  grid.u[,1] = grid.l[,2]
  grid.u[,2] = grid.l[,1]
  grid.u[,3] = grid.l[,3]
  grid = rbind(grid.l, grid.u)
  
  cmbn = combn(lp, 2)
  cmbn = cmbn[c(2,1),]
  W.all = matrix(NA,nrow=ncol(cmbn),ncol = 4)
  W.all[,1] = S[cbind(cmbn[1,],cmbn[1,])]
  W.all[,2] = S[cbind(cmbn[1,],cmbn[2,])]
  W.all[,3] = W.all[,2]
  W.all[,4] = S[cbind(cmbn[2,],cmbn[2,])]
  det.W = W.all[,1] * W.all[,4] - W.all[,2]^2
  
  log.det.w = log(det.W)
  log.I1 = (ln-3)/2*log.det.w
  log.I4 = ln*log(2)+log(pi)/2+log(gamma(ln/2)) + log(gamma((ln-1)/2))
  
  D = apply(grid, 1, function(x) {
    ## off-diagonal
    sigma = matrix(c(x[1]^2, prod(x), prod(x), x[2]^2),nrow = 2)
    inv.sigma = solve(sigma)
    
    log.I2 = -(W.all %*% as.vector(inv.sigma)) / 2
    log.I3 = ln / 2 * log(det(sigma))
    tmp = log.I1 + log.I2 - log.I3 - log.I4
    off = exp(tmp)
    ## on-diagonal is scaled chi-square
    on = dchisq(diag(S)/x[1]^2, ln) * ln / x[1]^2
    return(c(off, on))
  })
  g = npmle2(D, maxit, tol, verbose)
  ind = lp * (lp-1) / 2 
  
  ## estimated covariance matrix
  denom = D %*% g
  tmp_nd = D[1:ind,] %*% (g * apply(grid, 1, prod)) / denom[1:ind]
  tmp_d = D[(ind+1):(ind+lp),] %*% (g * grid[,1]^2) / denom[(ind+1):(ind+lp)]
  est_cov = matrix(0, lp, lp)
  est_cov[cbind(cmbn[1,],cmbn[2,])] = as.vector(tmp_nd)
  est_cov[cbind(cmbn[2,],cmbn[1,])] = as.vector(tmp_nd)
  diag(est_cov) = as.vector(tmp_d)
  
  return(est_cov)
}

