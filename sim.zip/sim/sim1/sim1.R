rm(list=ls())
lib.path = '~/rlib/'
.libPaths(lib.path)
library(pracma)
library(matrixStats)
library(doParallel)
library(foreach)
source('~/cov3/methods.R')

# source('/Users/xinxin/cov_mat/sim12_par/methods.R')
ps = c(30,100,200)
T.max = 200
n = 100
scalers = c(2,1,0.5,0.25)
n.methods = length(scalers) + 1
mat.types = c('sparse','dense','dense2')

n.cluster = detectCores()
print(paste(n.cluster,'clusters are detected.'))
cl = makeCluster(2)
registerDoParallel(cl)
clusterEvalQ(cl, .libPaths('~/rlib/'))
for (k in 1:length(mat.types))
{
  print(paste('simulation for',mat.types[k]))
  # construct error matrix
  f.median = matrix(0,nrow=n.methods, ncol=length(ps))
  colnames(f.median) = c('p=30','p=100','p=200')
  rownames(f.median) = c('no_cluster',
    sapply(scalers, function(x) paste0('ratio=',x)))
  f.range = f.median
  t.mean = f.median
  start_time_all <- Sys.time()
  for (j in 1:length(ps))
  {
    p=ps[j]
    set.seed(123)
    sigma.x = build_matrix(p,choice = mat.types[k])
    
    res <- foreach(b = 1:T.max, .combine = "rbind", .packages = c('MASS','ashr','pracma','matrixStats')) %dopar% {
      .GlobalEnv$sigma.x <- sigma.x 
      .GlobalEnv$npmle2 <- npmle2
      X = mvrnorm(n,mu=rep(0,p),Sigma = sigma.x)
      f_errs = rep(0,n.methods)
      ts = rep(0,n.methods)
      
      start_time <- Sys.time()
      mat.hat = posdef.correction(msg_sgrid(X,fun=npmle2,centered = T),d=20,lp=p)
      end_time <- Sys.time()
      f_errs[1] = norm(sigma.x-mat.hat, type = "f")
      ts[1] = end_time - start_time
      
      for (im in 2:n.methods)
      {
        print(im)
        start_time <- Sys.time()
        est_cov = msg_sgrid_km(X,fun=npmle2,K=p*scalers[im-1],centered = T)
        mat.hat = posdef.correction(est_cov,d=20,lp=p)
        end_time <- Sys.time()
        
        f_errs[im] = norm(sigma.x-mat.hat, type = "f")
        ts[im] = end_time - start_time
        
      }
      c(f_errs, ts)
    }
    
    f.median[,j] = colMedians(res[,1:n.methods]) 
    f.range[,j] = colQuantiles(res[,1:n.methods], probs = 0.75) -
      colQuantiles(res[,1:n.methods], probs = 0.25)
    t.mean[,j] = colMeans(res[,(n.methods+1):(2*n.methods)]) 
    
  }
  end_time_all <- Sys.time()
  t_all = end_time_all - start_time_all
  print(f.median)
  print(f.range)
  print(t.mean) 
  print(t_all)
}
stopCluster(cl)