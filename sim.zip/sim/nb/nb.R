rm(list=ls())
lib.path = '~/rlib/'
.libPaths(lib.path)
library(pracma)
library(matrixStats)
library(doParallel)
library(foreach)
source('~/cov_new/methods.R')

# source('/Users/xinxin/cov_mat/sim12_par/methods.R')
ps = c(30,100,200)
T.max = 200
n = 100
methods = list(msg_sgrid_km,posdef.correction, adap.thrsd, 
               linear,QIS,NERCOME,corShrink,SCM,
               oracle_nonlin,oracle_gmleb)
n.methods = length(methods) # positive correction and sample cov matrix

n.cluster = detectCores()
print(paste(n.cluster,'clusters are detected.'))
cl = makeCluster(2)
registerDoParallel(cl)
clusterEvalQ(cl, .libPaths('~/rlib/'))
mat.types = c('sparse','block','dense')
for (k in 1:length(mat.types))
{
  print(paste('simulation for',mat.types[k]))
  # construct error matrix
  f.median = matrix(0,nrow=n.methods, ncol=length(ps))
  colnames(f.median) = c('p=30','p=100','p=200')
  rownames(f.median) = c('msg_sgrid_km','msg_km_cor','adap.thrsd', 'linear',
                       'QIS','NERCOME','corShrink','SCM',
                       'oracle_nonlin','oracle_gmleb')
  f.range = f.median
  t.mean = f.median
  
  start_time_all <- Sys.time()
  for (j in 1:length(ps))
  {
    p=ps[j]
    set.seed(123)
    sigma.x = build_matrix(p,choice = mat.types[k])
    L = chol(sigma.x)
    v = 5.6
    #sigma.x = L%*%diag(v,p)%*%t(L)
  
    res <- foreach(b = 1:T.max, .combine = "rbind", .packages = c('ashr','pracma','matrixStats')) %dopar% {
      .GlobalEnv$sigma.x <- sigma.x 
      .GlobalEnv$npmle2 <- npmle2
      .GlobalEnv$pos.cor.cor <- pos.cor.cor
      # to make x has mean of 0, substract 0.5 for each data point generated from beta distribution.
      X.ind = matrix(rnbinom(n*p,mu=4,size=10),nrow=p,ncol=n)
      X.ind = (X.ind-4)/sqrt(v) # scale X.ind to make its variance as 1
      X = t(t(L)%*%X.ind)
      f_errs = rep(0,n.methods)
      ts = rep(0,n.methods)
      for (im in 1:n.methods)
      {
        g = methods[[im]]
        start_time <- Sys.time()
        if (im == 1) # msg_sgrid_km
        {
          mat.hat = g(X,fun=npmle2,K=p,centered=TRUE)
        }
        else if(im == 2) # corrected msg_sgrid_km
        {
          mat.hat = g(mat.hat,d=20,lp=p)
        }
        else if(im == 10) # oracle gmleb
        {
          mat.hat = g(X,K=p,cov=sigma.x,centered=TRUE)
        }
        else if(im == 9) # oracle nonlinear
        {
          mat.hat = g(X,cov=sigma.x,centered=TRUE)
        }
        else if(im == 7) # corShrink
        {
          cor.hat = g(X)
          S = var(X)
          sd = sqrt(diag(S))
          mat.hat = diag(sd) %*% cor.hat %*% diag(sd)
        }
        else # other methods
        {
          mat.hat = g(X,centered=TRUE)
        }
        end_time <- Sys.time()
        
        f_errs[im] = norm(sigma.x-mat.hat, type = "f")
        ts[im] = end_time - start_time
        
      }
      c(f_errs, ts)
    }
    
    f.median[,j] = colMedians(res[,1:n.methods]) 
    f.range[,j] = colQuantiles(res[,1:n.methods], probs = 0.75) -
      colQuantiles(res[,1:n.methods], probs = 0.25)
    t.mean[,j] = colMeans(res[,(n.methods+1):(2*n.methods)]) 
    
  }
  end_time_all <- Sys.time()
  t_all = end_time_all - start_time_all
  # write.csv(f.mean, file=paste0('err_',mat.types[k],'.csv'))
  # write.csv(t.mean, file=paste0('time_',mat.types[k],'.csv'))
  
  print(f.median)
  print(f.range)
  print(t.mean) 
  print(t_all)
}
stopCluster(cl)
